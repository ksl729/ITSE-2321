namespace ImageViewerActivity
{
    public partial class imageViewer_Activity : Form
    {
        public imageViewer_Activity()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            lytpanel_side = new TableLayoutPanel();
            lytpanel_Main = new FlowLayoutPanel();
            btn_exit = new Button();
            btn_choose = new Button();
            btn_pick_color = new Button();
            picbox_Main = new PictureBox();
            chk_stretch = new CheckBox();
            PictureSelection = new OpenFileDialog();
            colorDialog1 = new ColorDialog();
            lytpanel_side.SuspendLayout();
            lytpanel_Main.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picbox_Main).BeginInit();
            SuspendLayout();
            // 
            // lytpanel_side
            // 
            lytpanel_side.ColumnCount = 2;
            lytpanel_side.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 21.45229F));
            lytpanel_side.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 78.54771F));
            lytpanel_side.Controls.Add(lytpanel_Main, 1, 1);
            lytpanel_side.Controls.Add(picbox_Main, 1, 0);
            lytpanel_side.Controls.Add(chk_stretch, 0, 1);
            lytpanel_side.Location = new Point(1, 0);
            lytpanel_side.Name = "lytpanel_side";
            lytpanel_side.RowCount = 2;
            lytpanel_side.RowStyles.Add(new RowStyle(SizeType.Percent, 61.53846F));
            lytpanel_side.RowStyles.Add(new RowStyle(SizeType.Percent, 38.46154F));
            lytpanel_side.Size = new Size(961, 488);
            lytpanel_side.TabIndex = 0;
            // 
            // lytpanel_Main
            // 
            lytpanel_Main.Controls.Add(btn_exit);
            lytpanel_Main.Controls.Add(btn_choose);
            lytpanel_Main.Controls.Add(btn_pick_color);
            lytpanel_Main.Location = new Point(209, 303);
            lytpanel_Main.Name = "lytpanel_Main";
            lytpanel_Main.Size = new Size(749, 182);
            lytpanel_Main.TabIndex = 2;
            // 
            // btn_exit
            // 
            btn_exit.BackColor = SystemColors.ControlDarkDark;
            btn_exit.ForeColor = SystemColors.ButtonHighlight;
            btn_exit.Location = new Point(3, 3);
            btn_exit.Name = "btn_exit";
            btn_exit.Size = new Size(75, 23);
            btn_exit.TabIndex = 0;
            btn_exit.Text = "Exit";
            btn_exit.UseVisualStyleBackColor = false;
            btn_exit.Click += btn_exit_Click;
            // 
            // btn_choose
            // 
            btn_choose.AutoSize = true;
            btn_choose.BackColor = SystemColors.ControlDark;
            btn_choose.ForeColor = SystemColors.ButtonHighlight;
            btn_choose.Location = new Point(84, 3);
            btn_choose.Name = "btn_choose";
            btn_choose.Size = new Size(93, 25);
            btn_choose.TabIndex = 1;
            btn_choose.Text = "Choose Image";
            btn_choose.UseVisualStyleBackColor = false;
            btn_choose.Click += btn_choose_Click;
            // 
            // btn_pick_color
            // 
            btn_pick_color.AutoSize = true;
            btn_pick_color.Location = new Point(183, 3);
            btn_pick_color.Name = "btn_pick_color";
            btn_pick_color.Size = new Size(89, 25);
            btn_pick_color.TabIndex = 2;
            btn_pick_color.Text = "Choose Color";
            btn_pick_color.UseVisualStyleBackColor = true;
            btn_pick_color.Click += btn_pick_color_Click;
            // 
            // picbox_Main
            // 
            picbox_Main.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            picbox_Main.BorderStyle = BorderStyle.FixedSingle;
            picbox_Main.Location = new Point(209, 3);
            picbox_Main.Name = "picbox_Main";
            picbox_Main.Size = new Size(749, 294);
            picbox_Main.TabIndex = 0;
            picbox_Main.TabStop = false;
            // 
            // chk_stretch
            // 
            chk_stretch.AutoSize = true;
            chk_stretch.BackColor = SystemColors.ControlDarkDark;
            chk_stretch.ForeColor = SystemColors.ButtonHighlight;
            chk_stretch.Location = new Point(3, 303);
            chk_stretch.Name = "chk_stretch";
            chk_stretch.Size = new Size(63, 19);
            chk_stretch.TabIndex = 3;
            chk_stretch.Text = "Stretch";
            chk_stretch.UseVisualStyleBackColor = false;
            chk_stretch.CheckedChanged += chk_stretch_CheckedChanged;
            // 
            // PictureSelection
            // 
            PictureSelection.FileName = "Picture Selection";
            // 
            // imageViewer_Activity
            // 
            BackColor = SystemColors.Desktop;
            ClientSize = new Size(958, 485);
            Controls.Add(lytpanel_side);
            Name = "imageViewer_Activity";
            Text = "Image Viewer Activity";
            Load += imageViewer_Activity_Load;
            lytpanel_side.ResumeLayout(false);
            lytpanel_side.PerformLayout();
            lytpanel_Main.ResumeLayout(false);
            lytpanel_Main.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picbox_Main).EndInit();
            ResumeLayout(false);

        }

        private TableLayoutPanel lytpanel_side;
        private PictureBox picbox_Main;
        private FlowLayoutPanel lytpanel_Main;
        private Button btn_exit;
        private Button btn_choose;
        private Button btn_pick_color;
        private CheckBox chk_stretch;
        private OpenFileDialog PictureSelection;

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_choose_Click(object sender, EventArgs e)
        {
            if (PictureSelection.ShowDialog() == DialogResult.OK)
            {
                picbox_Main.Image = Image.FromFile(PictureSelection.FileName);
            }
        }

        private void btn_pick_color_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                picbox_Main.BackColor = colorDialog1.Color;
            }
        }

        private void imageViewer_Activity_Load(object sender, EventArgs e)
        {

        }

        private void chk_stretch_CheckedChanged(object sender, EventArgs e)
        {
            if(chk_stretch.Checked)
            {
                picbox_Main.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
            {
                picbox_Main.SizeMode = PictureBoxSizeMode.Normal;
            }
        }

        private ColorDialog colorDialog1;
    }
}
